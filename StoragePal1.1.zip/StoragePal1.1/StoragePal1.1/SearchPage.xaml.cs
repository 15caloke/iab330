﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace StoragePal1
{
    public partial class SearchPage : ContentPage
    {
        public SearchPage()
        {
            InitializeComponent();
        }
    }
}
