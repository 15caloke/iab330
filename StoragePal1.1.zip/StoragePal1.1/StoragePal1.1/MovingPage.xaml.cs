﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace StoragePal1
{
    public partial class MovingPage : ContentPage
    {
        public MovingPage()
        {
            InitializeComponent();
        }
    }
}
