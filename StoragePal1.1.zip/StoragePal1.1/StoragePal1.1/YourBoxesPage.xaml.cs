﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace StoragePal1
{
    public partial class YourBoxesPage : ContentPage
    {
        public YourBoxesPage()
        {
            InitializeComponent();
        }
    }
}
