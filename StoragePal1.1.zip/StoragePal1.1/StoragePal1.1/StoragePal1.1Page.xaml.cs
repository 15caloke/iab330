﻿using Xamarin.Forms;

namespace StoragePal1
{
    public partial class StoragePal1_1Page : TabbedPage
    {
        public StoragePal1_1Page()
        {
            InitializeComponent();
        }
    }
}
